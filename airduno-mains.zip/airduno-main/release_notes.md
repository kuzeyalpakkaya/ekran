# Release Notes

--------------------------------------------------------------------------------

# Release v1.9.5.2

  - version: v1.9.5.2
  - base: v1.9.5.2
  
## Brief

Support all components in Airhmi Visual Designer v1.9.5.2. 

## Details

Added APIs of new attrubutes and components supported by AirHmi Visual Designer v1.9.5.2.


# Release v1.9.5.2

  - version: v1.9.5.2
  - base: no base version
  - author: Omer Aygor <oaygor@eyzateknoloji.com>
  - date: 12/17/2023 13:17:20 

## Brief

Support all components in AirHMI Visual Designer v1.9.5.2. 

## Details

First release. 


--------------------------------------------------------------------------------

# The End!

--------------------------------------------------------------------------------
