#include "AirHardware.h"
#ifdef ESP32
    #include "HardwareSerial.h"
    HardwareSerial AirHMI_Serial(1);  // UART1 tanımı
#endif

/*
 * Send command to AirHMI.
 */
void sendCommand(const char* cmd)
{
    while (AirHMI_Serial.available())
    {
        AirHMI_Serial.read();
    }
    AirHMI_Serial.print(cmd);
    AirHMI_Serial.write(0xFF);
    AirHMI_Serial.write(0xFF);
    AirHMI_Serial.write(0xFF);
}

/*
 * Initialize AirHMI communication
 */
bool airInit(void)
{
    AirHMI_Serial.begin(115200, SERIAL_8N1, 16, 17);  // ESP32 UART1 GPIO16/RX, GPIO17/TX
    return true;
}

/*
 * Command completion check
 */
bool recvRetCommandFinished(uint32_t timeout)
{
    uint32_t start = millis();
    while (millis() - start <= timeout)
    {
        while (AirHMI_Serial.available())
        {
            uint8_t c = AirHMI_Serial.read();
            if (c == 0xFF) return true;
        }
    }
    return false;
}
